package com.example.zamchat.di.builder

import dagger.Module

@Module
abstract class ViewModelModule {
/*
    @Binds
    @IntoMap
    @ViewModelKey(MainViewModel::class)
    abstract fun bindMainViewModel(viewModel: MainViewModel) : ViewModel*/
}